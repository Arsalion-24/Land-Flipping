# Deployment on Ubuntu

- Install Docker and Docker Compose
- Clone repo and cd into it
- `cp landflip-frontend/.env.example landflip-frontend/.env`
- `cp landflip-backend/.env.example landflip-backend/.env`
- `docker compose -f infra/docker-compose.yml up -d --build`
- Point reverse proxy to web:5173 and api:8000 with TLS
