from pydantic import BaseModel
from typing import Optional, List, Any

class ParcelBase(BaseModel):
    parcel_id: Optional[str] = None
    apn: Optional[str] = None
    owner_name: Optional[str] = None
    county: Optional[str] = None
    acreage: Optional[float] = None
    address: Optional[str] = None

class ParcelCreate(ParcelBase):
    geom_wkt: Optional[str] = None

class ParcelOut(ParcelBase):
    id: int
    class Config:
        from_attributes = True

class GeoJSONFeature(BaseModel):
    type: str
    geometry: Any
    properties: dict

class GeoJSONFeatureCollection(BaseModel):
    type: str
    features: List[GeoJSONFeature]
