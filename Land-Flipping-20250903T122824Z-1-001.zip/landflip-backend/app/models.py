from sqlalchemy import Column, Integer, String, Numeric, Text, ForeignKey, DateTime, func
from sqlalchemy.orm import relationship
from geoalchemy2 import Geometry
from .db import Base

class Parcel(Base):
    __tablename__ = "parcels"
    id = Column(Integer, primary_key=True, index=True)
    parcel_id = Column(String(128), index=True)
    apn = Column(String(128), index=True)
    owner_name = Column(String(256), index=True)
    county = Column(String(128), index=True)
    acreage = Column(Numeric)
    address = Column(Text)
    geom = Column(Geometry("POLYGON", srid=4326))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Owner(Base):
    __tablename__ = "owners"
    id = Column(Integer, primary_key=True)
    name = Column(String(256), index=True)

class Campaign(Base):
    __tablename__ = "campaigns"
    id = Column(Integer, primary_key=True)
    name = Column(String(256), index=True)
    channel = Column(String(64))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Interaction(Base):
    __tablename__ = "interactions"
    id = Column(Integer, primary_key=True)
    parcel_id = Column(Integer, ForeignKey("parcels.id"))
    channel = Column(String(64))
    direction = Column(String(16))
    status = Column(String(64))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
