from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import API_CORS_ORIGINS
from .db import Base, engine
from .routers import health, parcels

app = FastAPI(title="Land Flipping Automation API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in API_CORS_ORIGINS if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

app.include_router(health.router)
app.include_router(parcels.router)
