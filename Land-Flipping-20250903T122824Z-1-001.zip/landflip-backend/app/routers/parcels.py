from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from shapely import wkt, wkb
from shapely.geometry import mapping
from geoalchemy2.shape import from_shape
import csv
import io
from typing import List
from ..db import get_db
from .. import models, schemas

router = APIRouter(prefix="/parcels", tags=["parcels"])

@router.get("/", response_model=List[schemas.ParcelOut])
def list_parcels(db: Session = Depends(get_db)):
    return db.query(models.Parcel).limit(500).all()

@router.get("/geojson", response_model=schemas.GeoJSONFeatureCollection)
def parcels_geojson(db: Session = Depends(get_db)):
    features = []
    for p in db.query(models.Parcel).limit(1000).all():
        geom_geojson = None
        if p.geom is not None:
            try:
                shape = wkb.loads(bytes(p.geom.data))
                geom_geojson = mapping(shape)
            except Exception:
                geom_geojson = None
        features.append({
            "type": "Feature",
            "geometry": geom_geojson,
            "properties": {
                "id": p.id,
                "parcel_id": p.parcel_id,
                "apn": p.apn,
                "owner_name": p.owner_name,
                "county": p.county,
                "acreage": float(p.acreage) if p.acreage is not None else None,
                "address": p.address,
            }
        })
    return {"type": "FeatureCollection", "features": features}

@router.post("/ingest-csv")
def ingest_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith((".csv", ".txt")):
        raise HTTPException(status_code=400, detail="Only CSV supported in MVP")
    data = file.file.read().decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(data))
    count = 0
    for row in reader:
        geom = None
        geom_wkt = row.get("geom_wkt") or row.get("WKT") or row.get("geometry")
        if geom_wkt:
            try:
                shape = wkt.loads(geom_wkt)
                geom = from_shape(shape, srid=4326)
            except Exception:
                geom = None
        parcel = models.Parcel(
            parcel_id=row.get("parcel_id") or row.get("ParcelID") or row.get("parcel") or None,
            apn=row.get("apn") or row.get("APN") or None,
            owner_name=row.get("owner") or row.get("owner_name") or None,
            county=row.get("county") or row.get("County") or None,
            acreage=(float(row.get("acreage")) if row.get("acreage") else None),
            address=row.get("address") or None,
            geom=geom,
        )
        db.add(parcel)
        count += 1
        if count % 500 == 0:
            db.commit()
    db.commit()
    return {"ingested": count}
