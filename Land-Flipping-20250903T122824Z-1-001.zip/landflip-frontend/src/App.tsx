import { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const API = (import.meta.env.VITE_API_BASE as string) || "http://localhost:8000";

export default function Home() {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const mapInstance = useRef<maplibregl.Map | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (mapRef.current && !mapInstance.current) {
      const map = new maplibregl.Map({
        container: mapRef.current,
        style: "https://demotiles.maplibre.org/style.json",
        center: [-98, 39],
        zoom: 3,
      });
      map.on("load", async () => {
        try {
          const res = await fetch(`${API}/parcels/geojson`);
          const data = await res.json();
          map.addSource("parcels", { type: "geojson", data });
          map.addLayer({
            id: "parcels-fill",
            type: "fill",
            source: "parcels",
            paint: { "fill-color": "#3b82f6", "fill-opacity": 0.2 },
          });
          map.addLayer({
            id: "parcels-outline",
            type: "line",
            source: "parcels",
            paint: { "line-color": "#1d4ed8", "line-width": 1 },
          });
        } catch {}
      });
      mapInstance.current = map;
    }
  }, []);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    setMessage("");
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch(`${API}/parcels/ingest-csv`, {
        method: "POST",
        body: form,
      });
      const json = await res.json();
      setMessage(`Ingested ${json.ingested} rows`);
      if (mapInstance.current) {
        const res2 = await fetch(`${API}/parcels/geojson`);
        const data = await res2.json();
        const src = mapInstance.current.getSource("parcels") as maplibregl.GeoJSONSource;
        if (src) src.setData(data as any);
      }
    } catch (err) {
      setMessage("Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto grid max-w-6xl gap-6 p-6 md:grid-cols-5">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Bulk CSV Import</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpload} className="space-y-3">
              <Input type="file" accept=".csv,text/csv" onChange={(e) => setFile(e.target.files?.[0] || null)} />
              <Button type="submit" disabled={!file || uploading}>{uploading ? "Uploading..." : "Upload"}</Button>
              {message && <p className="text-sm text-muted-foreground">{message}</p>}
              <p className="text-xs text-muted-foreground">Columns supported: parcel_id, apn, owner_name, county, acreage, address, geom_wkt</p>
            </form>
          </CardContent>
        </Card>
        <Card className="md:col-span-3">
          <CardHeader>
            <CardTitle>Parcels Map</CardTitle>
          </CardHeader>
          <CardContent>
            <div ref={mapRef} className="h-[500px] w-full rounded-md border" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
